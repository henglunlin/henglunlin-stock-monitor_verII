# 台股監控器 — React 版

用 React 前端取代 Streamlit，主攻**訊號顯示密度與排版自由度**。
後端沿用原本的 Python 邏輯，只是把呼叫者從 Streamlit 換成 FastAPI。

舊的 Streamlit 版留在 [`henglunlin-stock-monitor-FUBAN`](https://github.com/henglunlin/henglunlin-stock-monitor-FUBAN) 並行運作，這個 repo 不影響它。

---

## 架構

```
富邦 Neo WebSocket ─┐
                    ├─→ Render（FastAPI + 富邦 SDK）─→ WebSocket ─→ Vercel（React）
GitHub Actions ─────┘         └─→ Telegram
（排程掃描、資料同步）
```

| 元件 | 放哪 | 費用 |
|---|---|---|
| React 前端 | Vercel | 免費 |
| FastAPI + 富邦 SDK | Render（**Region 選 Singapore**） | 免費 |
| 排程掃描、資料儲存 | GitHub | 免費 |

**月成本 NT$0，不需要開自己的電腦。**

---

## 目錄

```
core/                 純 Python 邏輯層，零 UI 依賴（13 支）
scripts/selftest.py   環境自我檢測，一個指令確認裝對了沒
server/               FastAPI 應用層，只做接線（3 支）
web/                  Vite + React + TypeScript 前端
signal_module/        訊號模組（由 GitHub Actions 從 monitor repo 單向同步）
.github/workflows/    同步排程
render.yaml           Render 部署設定
```

---

## 快速開始

**後端**

```bash
python -m venv .venv
.venv\Scripts\activate                 # Windows；Mac/Linux 用 source .venv/bin/activate

pip install -r server/requirements.txt

# 富邦 SDK 分平台，要另外裝：
pip install .\fubon_neo-2.2.8-cp37-abi3-win_amd64.whl        # Windows
# pip install ./fubon_neo-2.2.8-...-manylinux_2_17_x86_64...whl   # Linux/Mac

cp .env.example .env          # 填入 FUBON_PFX_BASE64
python scripts/selftest.py    # 一個指令確認環境齊全
uvicorn server.main:app --reload --port 8000
```

> **為什麼富邦 SDK 要分開裝**：它的 whl 是分平台的，而 pip 在評估環境標記
> 之前就會先去找檔案，沒辦法用 `; sys_platform == 'linux'` 把兩個平台寫進
> 同一份 requirements。所以本機用 `server/requirements.txt`，
> Render 用 `server/requirements-render.txt`（多帶 Linux 版 whl）。

**前端**（另開一個終端機）

```bash
cd web
npm install
npm run dev                   # http://localhost:5173
```

開發時 Vite 的 proxy 會把 `/api` 與 `/ws` 轉發到 `localhost:8000`，
所以本機不會踩到 CORS。

---

## 環境變數

`.env`（後端，**務必加進 .gitignore**）

```ini
FUBON_PFX_BASE64=MIIK...        # 憑證，唯一放上雲的敏感資料
APP_SHARED_TOKEN=一組夠長的隨機字串
ALLOWED_ORIGINS=https://你的.vercel.app,http://localhost:5173
TELEGRAM_BOT_TOKEN=
TELEGRAM_CHAT_ID=
GITHUB_TOKEN=
```

**身分證／密碼／憑證密碼刻意不放環境變數**，改由前端呼叫
`POST /api/fubon/login` 手動輸入，一天一次。這是為了讓帳密留在你手上。

`web/.env`（前端，部署到 Vercel 時設在 Vercel 的 Environment Variables）

```ini
VITE_API_BASE=https://你的服務.onrender.com
VITE_APP_TOKEN=跟上面 APP_SHARED_TOKEN 相同的字串
```

---

## 部署

**Render（後端）** — Region **一定要選 Singapore**，離台灣最近，比美國機房少約 200ms。
用 repo 裡的 `render.yaml`，或手動設定：

- Build：`pip install -r server/requirements-render.txt`
- Start：`uvicorn server.main:app --host 0.0.0.0 --port $PORT`
- Health Check：`/api/health`

**Vercel（前端）** — Root Directory 設成 `web`，其餘用預設（Vite 會被自動偵測）。

---

## 版面

儀表板是主畫面，其餘都是浮動視窗——看盤時九成的時間你問的是「哪一類在動」，
而不是「第 87 檔的 KD 是多少」。原版把表格放主位、儀表板擠在上面，
等於把一成的需求擺在九成前面。

```
狀態列  ← 連線／富邦／tick 數／暫停中提示
工具列  ← 手動更新、啟用自動更新、慢線秒數、Telegram、定時推送、全部股票、設定、登入
加權指數走勢（可收合）
┌────────────────────────────────────────┐
│  漲幅儀表板（滿版，自己捲）                │
│  19 張分類卡片，可依分類順序／達標比例／檔數排序 │
└────────────────────────────────────────┘
        ↓ 點卡片
   分類清單（浮動視窗，虛擬捲動表格）
        ↓ 點任一列
   個股詳情（浮動視窗，盤中走勢＋開高低＋指標＋訊號＋買入區間）
```

關掉個股詳情會回到它的來源清單，不是回到儀表板——不然每看一檔就要重點一次分類。

**表格活在浮動視窗裡是刻意的。** 之前把儀表板跟表格塞進同一個捲動容器，
virtualizer 預設假設清單從容器頂端開始，上面墊著的儀表板高度沒被計入，
表頭下方就出現一大塊空白。浮動視窗天生擁有自己的捲動區，結構上不可能再犯。

---

## 走勢欄畫的是「今天」

表格的「走勢」欄預設畫**當日盤中走勢**，不是近 30 日收盤。虛線是昨收，
沒有它讀不出「現在在平盤上還是下」——迷你圖是自動縮放的，畫的是相對起伏。

資料哪裡來：富邦每筆 tick 進來時，後端在記憶體裡累積一條**每 20 秒一個點**的序列
（每檔上限 900 點，換日自動清空）。慢線每次送整列時附上取樣過的 40 點，
前端再用快線的報價把最後 20 秒補上，所以線尾跟價格欄是同步跳的。

**這條序列不打任何 REST。** 對 193 檔各叫一次富邦分鐘 K 一定撞 429，
所以分鐘 K 只在「點開單檔詳情」時呼叫，一次一檔。

尚未登入富邦、盤前或假日時沒有盤中資料，走勢欄自動退回近 30 日收盤——
否則開盤前整欄空白會看起來像壞掉。

---

## 三個開關的語意，跟原版不完全一樣

原版那個「刷新秒數 3 秒」是**整頁重跑**的間隔，而整頁重跑同時做了兩件事：
抓最新報價、重算所有指標與訊號。新架構把這兩件事拆開了，所以一個開關變成兩個：

| 新架構 | 控制什麼 | 對應原版的哪一半 |
|---|---|---|
| 啟用自動更新 | 前端是否套用推送進來的資料。暫停時畫面凍結，WebSocket 仍連著，解除立刻跳回最新 | 「要不要一直跳」 |
| 慢線秒數 | 後端重算指標與訊號的間隔，會真的送到後端存起來 | 「多久重算一次」 |
| 快線間隔（設定裡） | 報價推送的節流間隔，預設 300ms | 原版沒有這個粒度 |

快線沒有「關閉」選項，因為它幾乎不花成本：只推這段時間內變動過的股票，
沒變動就完全不發包。關掉省不到什麼，卻會讓價格停在舊值。

---

## 這個設計的兩個關鍵決定

### 一、快慢兩線

原本 Streamlit 每 3 秒把所有東西重算一次——報價、指標、22 個訊號、整張表重繪。
檔數一多就是這樣拖垮的。現在拆開：

| | 間隔 | 內容 |
|---|---|---|
| **快線** | 300ms | 只推這段時間內變動過的報價，沒變動就完全不發 |
| **慢線** | 20s | 重算技術指標、跑訊號、比對目標價 |

前端收到快線只更新價格那一格，收到慢線才更新整列。這是「只有變動的格子會閃」
與「幾百檔不卡」的來源。

### 二、心跳不是可選的

Render 免費方案 15 分鐘沒有 inbound 流量就休眠，而官方明確說明
**WebSocket 訊息算 inbound 流量**。前端每 30 秒送一次 `ping`，
這是盤中服務不會睡著的唯一機制，拿掉的話午休回來就會斷線。

---

## 訊號模組的同步

`signal_module/` 是從 monitor repo **單向同步**過來的複本，由
`.github/workflows/sync-from-monitor.yml` 每個交易日早上 08:00 自動更新。

**請不要在這個 repo 直接改 `signal_module/`** —— 下次同步會被覆蓋。
要改訊號請到 monitor repo 的「🛠️ 訊號編輯」頁，這邊會自動跟上。

同步的還有 `twse_ohlcv.db`、`stock_groups.json`、`target_price_list.json`、
`trendline_levels.json` 與富邦 whl。

---

## 已知限制（原版就有，刻意維持一致）

**沒有國定假日行事曆** — `get_history_cutoff_date()` 只用星期幾判斷，
春節端午會算錯一天。搬家階段維持與原版相同行為，才能比對新舊版。

**盤後模式 + db 且 db 尚無今日資料時，漲跌幅顯示 0%** — 當下價與昨收都取到
同一筆歷史收盤。與原版邏輯一致，不是新架構造成的。

---

## 還沒搬過來的原版功能

主畫面（`0_💻_monitor.py`）的功能都在了。還沒搬的是**另外兩個分頁**，
它們各自是一整套編輯介面：

| 原版分頁 | 狀態 | 現在怎麼辦 |
|---|---|---|
| `1_🛠️_signal editor.py` 訊號編輯 | 未搬 | 去 monitor repo 那頁改，`signal_module/` 每天 08:00 自動同步過來 |
| `2_🎯_目標價編輯.py` 目標價編輯 | 未搬 | 同上，改 `target_price_list.json` |
| 股票分組編輯（側邊欄，PIN 保護） | 未搬 UI，API 已有 | 後端 `PUT /api/groups` 可用，還沒接介面 |

**PIN 唯讀模式刻意沒有搬。** 那是為了「多人共用同一個公開網址」設計的，
新架構擋在前面的是 `X-App-Token`：沒有 token 的人根本連不到 API，
不需要再用 PIN 擋一次編輯權限。

---

## 進度

- [x] Phase 0 — 後端脫殼：`core/` 13 支 + `server/` 3 支
- [x] Phase 1 — React 骨架、WebSocket、虛擬捲動表格
- [x] Phase 2 — 走勢圖、買入區間量尺、訊號徽章
- [x] 漲幅儀表板（即時聚合）＋ 依分類顯示
- [x] 儀表板改為滿版主畫面，分類清單／個股詳情／設定改為浮動視窗
- [x] 走勢欄改為當日盤中走勢（含昨收基準線）；加權指數走勢；工具列開關
- [ ] Phase 3 — 分組編輯 UI、K 線圖、欄位自訂、手機版
- [ ] 實機驗收：盤中登入富邦，確認 `subscribed_count` 與 `tick_count` 有在跳
