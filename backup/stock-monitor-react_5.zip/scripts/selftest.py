# -*- coding: utf-8 -*-
"""
本地環境自我檢測。

    python scripts/selftest.py

不需要富邦憑證、不需要盤中、不需要網路（全程走本地 SQLite）。
一路綠燈代表後端環境是好的，可以往下做前端。

每一項失敗都會告訴你「怎麼修」，不會只丟一個 traceback。
"""
from __future__ import annotations

import importlib
import os
import sys
import traceback
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

PASS, FAIL, WARN = "  [OK]  ", "  [!!]  ", "  [--]  "
failures: list[str] = []


def ok(msg: str) -> None:
    print(PASS + msg)


def bad(msg: str, fix: str) -> None:
    print(FAIL + msg)
    print(f"         → 怎麼修：{fix}")
    failures.append(msg)


def warn(msg: str, note: str = "") -> None:
    print(WARN + msg)
    if note:
        print(f"         {note}")


def section(title: str) -> None:
    print(f"\n{'=' * 62}\n{title}\n{'=' * 62}")


# =============================================================================
section("1. Python 與套件")
# =============================================================================
v = sys.version_info
if v >= (3, 11):
    ok(f"Python {v.major}.{v.minor}.{v.micro}")
else:
    bad(
        f"Python {v.major}.{v.minor} 太舊",
        "需要 3.11 以上（Render 也是用 3.11）。裝新版後重建虛擬環境。",
    )

for mod, hint in [
    ("fastapi", "pip install -r server/requirements.txt"),
    ("uvicorn", "pip install -r server/requirements.txt"),
    ("pandas", "pip install pandas"),
    ("yfinance", "pip install yfinance"),
    ("requests", "pip install requests"),
]:
    try:
        m = importlib.import_module(mod)
        ok(f"{mod} {getattr(m, '__version__', '')}")
    except ImportError:
        bad(f"缺少套件 {mod}", hint)

try:
    importlib.import_module("fubon_neo")
    ok("fubon_neo SDK 已安裝")
except ImportError:
    warn(
        "fubon_neo SDK 未安裝",
        "非致命：服務仍會啟動，只是拿不到即時報價。\n"
        "         安裝：pip install ./fubon_neo-2.2.8-cp37-abi3-manylinux_2_17_x86_64.manylinux2014_x86_64.whl\n"
        "         ⚠️ 這個 whl 是 Linux 版。Windows 本機請改用富邦官網下載的 Windows 版 SDK。",
    )

# =============================================================================
section("2. 必要檔案（這些要從 monitor repo 複製過來）")
# =============================================================================
REQUIRED = [
    ("signal_module/base.py", "訊號模組核心", True),
    ("signal_module/module_loader.py", "訊號模組載入器", True),
    ("TWstocklistname2.txt", "股票代碼與名稱對照表", True),
    ("twse_ohlcv.db", "歷史 OHLCV 資料庫（38MB）", True),
    ("stock_groups.json", "股票分組", False),
    ("target_price_list.json", "目標價清單", False),
    ("trendline_levels.json", "趨勢線預算結果", False),
]
for rel, desc, required in REQUIRED:
    p = ROOT / rel
    if p.exists():
        size = p.stat().st_size
        ok(f"{rel:<38} {desc}（{size:,} bytes）")
    elif required:
        bad(
            f"找不到 {rel}（{desc}）",
            f"從 henglunlin-stock-monitor-FUBAN 複製 {rel} 到這個 repo 的相同位置。",
        )
    else:
        warn(f"找不到 {rel}（{desc}）", "非必要，缺了只是該功能不作用。")

n_signals = len(list((ROOT / "signal_module").glob("*.py"))) if (ROOT / "signal_module").exists() else 0
if n_signals >= 20:
    ok(f"signal_module/ 共 {n_signals} 支 .py")
elif n_signals:
    warn(f"signal_module/ 只有 {n_signals} 支 .py", "monitor repo 有 24 支，確認是不是漏複製了。")

# =============================================================================
section("3. 環境變數")
# =============================================================================
try:
    from core import config

    ok(f"REPO_ROOT = {config.REPO_ROOT}")
    if (ROOT / ".env").exists():
        ok(".env 存在（已自動載入）")
    else:
        warn(".env 不存在", "複製 .env.example 成 .env 再填。本地測試可以先不填。")

    checks = [
        ("FUBON_PFX_BASE64", config.get_secret_or_default("FUBON_PFX_BASE64"), "沒設就無法登入富邦，其餘功能不受影響"),
        ("APP_SHARED_TOKEN", config.APP_SHARED_TOKEN, "本地留空會自動放行；正式部署務必要設"),
        ("TELEGRAM_BOT_TOKEN", config.TELEGRAM_BOT_TOKEN, "沒設就不會推播"),
        ("GITHUB_TOKEN", config.get_secret_or_default("GITHUB_TOKEN"), "沒設就無法把分組同步回 GitHub"),
    ]
    for name, value, note in checks:
        if value:
            ok(f"{name} 已設定（{len(value)} 字元）")
        else:
            warn(f"{name} 未設定", note)
    ok(f"ALLOWED_ORIGINS = {config.ALLOWED_ORIGINS}")
except Exception:
    bad("core.config 匯入失敗", "看下面的 traceback")
    traceback.print_exc()

# =============================================================================
section("4. core/ 模組")
# =============================================================================
for mod in [
    "core.cache", "core.config", "core.state", "core.symbols", "core.tradingday",
    "core.db", "core.quotes", "core.indicators", "core.signals",
    "core.groups", "core.targets", "core.telegram", "core.fubon",
]:
    try:
        importlib.import_module(mod)
        ok(mod)
    except Exception as e:
        bad(f"{mod} 匯入失敗：{e}", "多半是缺套件或缺 signal_module/，看上面幾節")

# =============================================================================
section("5. 資料層（離線，走本地 SQLite）")
# =============================================================================
try:
    from core import db
    from core.symbols import get_stock_name, load_stock_lookup_maps
    from core.tradingday import today_str

    m = load_stock_lookup_maps()
    n = len(m["code_to_name"])
    if n > 1000:
        ok(f"股票對照表載入 {n} 檔（例：2330 = {get_stock_name('2330.TW')}）")
    else:
        bad(f"股票對照表只有 {n} 筆", "確認 TWstocklistname2.txt 完整")

    if db.db_available():
        hist = db.download_history_from_db("2330.TW", today_str(), False)
        price, dstr = db.get_db_latest_price("2330.TW")
        ok(f"twse_ohlcv.db 查詢正常：2330 有 {len(hist)} 筆歷史，最新收盤 {price} @ {dstr}")
        import datetime as _dt
        stale = (_dt.date.today() - _dt.date.fromisoformat(dstr)).days
        if stale > 5:
            warn(f"資料庫最新一筆是 {stale} 天前", "跑一次同步 workflow 或從 monitor repo 重新複製 twse_ohlcv.db")
    else:
        bad("找不到 twse_ohlcv.db", "從 monitor repo 複製過來（38MB）")
except Exception as e:
    bad(f"資料層測試失敗：{e}", "看 traceback")
    traceback.print_exc()

# =============================================================================
section("6. 訊號模組")
# =============================================================================
try:
    # ⚠️ 先 import server.hub，強制走「跟正式服務完全一樣」的 import 順序。
    # 曾經有一個 bug：core/targets.py 比 core/signals.py 先被 import，
    # 導致訊號註冊被跳過、只剩 2 個。如果這裡只 import core.signals，
    # 順序跟真實情況相反，就會顯示「20 個，一切正常」而完全測不出來。
    import server.hub  # noqa: F401
    from core.signals import SIGNAL_PRIORITY, get_signal_registry

    reg = get_signal_registry()
    if len(reg) >= 15:
        labels = [c["label"] for c in reg.values()]
        ok(f"已註冊 {len(reg)} 個訊號")
        print(f"         {'、'.join(labels[:9])}…")
        unknown = [l for l in labels if l not in SIGNAL_PRIORITY]
        if unknown:
            warn(f"這些訊號沒有在 SIGNAL_PRIORITY 裡：{unknown}", "會被當成最低優先等級 3，通常沒問題")
    else:
        bad(f"只註冊到 {len(reg)} 個訊號", "確認 signal_module/ 完整複製過來了")
except Exception as e:
    bad(f"訊號模組載入失敗：{e}", "看 traceback")
    traceback.print_exc()

# =============================================================================
section("7. 完整算一列（離線）")
# =============================================================================
try:
    from core.state import get_state
    from server.hub import hub

    S = get_state()
    S.settings.post_market_enabled = True     # 全程走 SQLite，不打網路
    S.settings.post_market_source = "db"
    S.stock_groups = {"自測": ["2330.TW", "2317.TW"]}

    rows = hub.compute_all_rows()
    good = [r for r in rows if "error" not in r]
    for r in rows:
        if "error" in r:
            warn(f"{r['symbol']} 計算失敗：{r['error']}")
        else:
            print(f"         {r['code']} {r['name']:<7} 價 {r['price']:>9} "
                  f"漲跌 {r['pct']:>6}%  KD {r['k']}/{r['d']}  "
                  f"{r['ma_range']:<8} {r['ma_trend']}  訊號 {r['signal_text']}")
    if len(good) == len(rows) and rows:
        ok(f"{len(good)} 檔全部算出，每列 {len(good[0])} 個欄位")
    elif good:
        warn(f"{len(good)}/{len(rows)} 檔算出", "部分失敗通常是那幾檔在資料庫裡沒資料")
    else:
        bad("一列都算不出來", "看上面的錯誤訊息")
except Exception as e:
    bad(f"整合測試失敗：{e}", "看 traceback")
    traceback.print_exc()

# =============================================================================
section("8. FastAPI 應用")
# =============================================================================
try:
    from server.main import app

    # 用 OpenAPI 來數端點，不要走 app.routes——不同 FastAPI 版本會把
    # include_router() 進來的路由包成單一節點，直接數 app.routes 會數成 0。
    api_routes = sorted(p for p in app.openapi()["paths"] if p.startswith("/api"))
    ok(f"app 建立成功，{len(api_routes)} 個 API 端點")
    print(f"         {', '.join(api_routes[:6])}…")

    ws_paths = [getattr(r, "path", None) for r in app.routes]
    if "/ws/quotes" in ws_paths:
        ok("WebSocket 端點 /ws/quotes 已註冊")
    else:
        bad("WebSocket 端點沒註冊", "檢查 server/main.py 的 @app.websocket 裝飾器")
    dist = ROOT / "web" / "dist"
    if dist.exists():
        ok(f"前端已建置：{dist}（會由 FastAPI 一併服務）")
    else:
        warn("web/dist 不存在", "還沒跑 npm run build。開發時走 Vite dev server 就好，不影響。")
except Exception as e:
    bad(f"FastAPI 應用建立失敗：{e}", "看 traceback")
    traceback.print_exc()

# =============================================================================
print("\n" + "=" * 62)
if failures:
    print(f"❌ {len(failures)} 項失敗，先修這些：")
    for f in failures:
        print(f"   • {f}")
    sys.exit(1)
print("✅ 全部通過。後端環境正常，可以啟動服務了：")
print("     uvicorn server.main:app --reload --port 8000")
sys.exit(0)
