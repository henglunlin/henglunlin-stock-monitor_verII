/**
 * 全域狀態（Zustand）。
 *
 * 設計重點：**報價與整列資料分開存放。**
 *
 * rows   來自慢線（每 20 秒），含指標、訊號、目標價，重
 * quotes 來自快線（每 300ms），只有 {代碼: 價格}，輕
 *
 * 表格渲染時把兩者疊起來：價格優先取 quotes，其餘欄位取 rows。
 * 這樣快線進來只會讓「價格那一格」重繪，不會動到整列 —— 這就是
 * 「只有變動的格子會閃」的實作方式，也是跟 Streamlit 整頁重跑最根本的差別。
 */
import { create } from 'zustand'
import type { ConnState, Row, Status } from './types'

/** localStorage 讀寫都要包 try/catch：無痕視窗或封鎖 cookie 時會直接丟例外 */
function readLS<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key)
    return raw ? (JSON.parse(raw) as T) : fallback
  } catch {
    return fallback
  }
}
function writeLS(key: string, value: unknown): void {
  try {
    localStorage.setItem(key, JSON.stringify(value))
  } catch {
    /* 存不進去就算了，這只是使用便利性，不是功能 */
  }
}

const LS_GROUPED = 'monitor.grouped.v1'
const LS_COLLAPSED = 'monitor.collapsed.v1'

interface AppStore {
  rows: Row[]
  /** 快線覆蓋的即時價 */
  quotes: Record<string, number>
  /** 每檔上次變動的方向與時間戳，用來決定閃紅還是閃綠 */
  flash: Record<string, { dir: 'up' | 'down'; at: number }>
  status: Status | null
  conn: ConnState
  wakeAttempt: number
  error: string | null
  selected: string | null

  /** 是否依分類分區顯示（關掉就是單一清單） */
  grouped: boolean
  /** 哪些分類被收合起來 */
  collapsed: Record<string, boolean>
  /** 儀表板點某張卡時，要捲到哪個分類 */
  scrollTo: string | null

  setRows: (rows: Row[]) => void
  applyQuotes: (data: Record<string, number>) => void
  setStatus: (s: Status) => void
  setConn: (c: ConnState) => void
  setWakeAttempt: (n: number) => void
  setError: (e: string | null) => void
  select: (symbol: string | null) => void
  setGrouped: (v: boolean) => void
  toggleCollapsed: (name: string) => void
  setAllCollapsed: (v: boolean, names: string[]) => void
  requestScrollTo: (name: string | null) => void
  /** 疊合後的當前價 */
  priceOf: (row: Row) => number
}

export const useStore = create<AppStore>((set, get) => ({
  rows: [],
  quotes: {},
  flash: {},
  status: null,
  conn: 'waking',
  wakeAttempt: 0,
  error: null,
  selected: null,
  grouped: readLS<boolean>(LS_GROUPED, true),
  collapsed: readLS<Record<string, boolean>>(LS_COLLAPSED, {}),
  scrollTo: null,

  setRows: (rows) => set({ rows }),

  applyQuotes: (data) =>
    set((state) => {
      const quotes = { ...state.quotes }
      const flash = { ...state.flash }
      const now = Date.now()
      for (const [code, price] of Object.entries(data)) {
        const prev = quotes[code]
        if (prev !== undefined && prev !== price) {
          flash[code] = { dir: price > prev ? 'up' : 'down', at: now }
        }
        quotes[code] = price
      }
      return { quotes, flash }
    }),

  setStatus: (status) => set({ status }),
  setConn: (conn) => set({ conn }),
  setWakeAttempt: (wakeAttempt) => set({ wakeAttempt }),
  setError: (error) => set({ error }),
  select: (selected) => set({ selected }),

  setGrouped: (grouped) => {
    writeLS(LS_GROUPED, grouped)
    set({ grouped })
  },

  toggleCollapsed: (name) =>
    set((state) => {
      const collapsed = { ...state.collapsed, [name]: !state.collapsed[name] }
      writeLS(LS_COLLAPSED, collapsed)
      return { collapsed }
    }),

  setAllCollapsed: (v, names) => {
    const collapsed: Record<string, boolean> = {}
    for (const n of names) collapsed[n] = v
    writeLS(LS_COLLAPSED, collapsed)
    set({ collapsed })
  },

  requestScrollTo: (scrollTo) => set({ scrollTo }),

  priceOf: (row) => {
    const q = get().quotes[row.code]
    return q !== undefined ? q : row.price
  },
}))

/** 依疊合後的價格重算漲跌幅（後端算的是慢線當下的，快線進來要跟著動） */
export function pctOf(row: Row, price: number): number {
  if (!row.yesterday_close) return row.pct
  return ((price / row.yesterday_close - 1) * 100)
}
