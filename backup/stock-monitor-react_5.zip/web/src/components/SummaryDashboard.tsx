/**
 * 漲幅儀表板 —— 對應 Streamlit 版的 render_summary_dashboard()。
 *
 * 三段計數的定義完全沿用原版：
 *   達標    pct >= rise_threshold（門檻來自後端 settings，不是寫死的）
 *   一般上漲 0 < pct < threshold
 *   下跌    pct < 0
 * （pct == 0 三邊都不算，跟原版一致）
 *
 * 比原版好的地方：**它是即時的**。
 * 原版每 3 秒整頁 rerun 才會更新一次；這裡直接吃快線覆蓋後的價格，
 * 報價一跳卡片數字就跟著動，不用等慢線那 20 秒。
 *
 * ── 為什麼這個聚合放在前端算，不違反「公式只留在 Python」原則 ──
 * 這裡只是「數有幾檔的 pct 超過門檻」，沒有任何訊號判斷或技術指標。
 * 真正的公式（KD、訊號、買入區間）全都是後端算好送過來的，前端一個都沒重算。
 *
 * ── 配色是驗證過的，不是挑順眼的 ──
 * 用 skill 附的 validate_palette.js 對深色底 #18181b 跑過：
 *   #e11d48 / #d97706 / #059669  → 亮度帶 PASS、對比 PASS，
 *   CVD 分離度 7.9 落在 6–8 下限帶，**僅在有次要編碼時合法**。
 * 所以比例條的每一段之間留 2px 間隙，而且下方一定同時有圖示＋文字標籤＋數字——
 * 識別永遠不只靠顏色。深色階是重新選的，不是把淺色翻轉。
 */
import { useMemo } from 'react'
import { pctOf, useStore } from '../store'
import type { Row } from '../types'

/** 比例條的填色：達標與一般上漲是同一色相的兩個階（有序），下跌是對比色相 */
const FILL_HIT = '#e11d48'   // rose-600
const FILL_UP = '#9f1239'    // rose-800，同色相較暗階＝「比較弱的上漲」
const FILL_DOWN = '#059669'  // emerald-600

interface GroupStat {
  name: string
  total: number
  hit: number
  up: number
  down: number
  ratio: number
  hitNames: string[]
  top3: Row[]
  top3Pct: number[]
}

/** 沿用原版 compact_name_list()：最多列 3 個，其餘用「等 N 檔」帶過 */
function compactNames(names: string[], maxShow = 3): string {
  if (names.length === 0) return '無'
  if (names.length <= maxShow) return names.join('、')
  return `${names.slice(0, maxShow).join('、')} 等${names.length}檔`
}

/** 依達標比例分三級。沿用原版語意：越熱越紅、完全沒有就是綠 */
function tierOf(ratio: number) {
  if (ratio >= 60) {
    return {
      accent: 'text-rose-400',
      border: 'border-rose-500/45',
      bg: 'bg-rose-500/[0.07]',
      ring: 'hover:border-rose-400/70',
    }
  }
  if (ratio > 0) {
    return {
      accent: 'text-amber-400',
      border: 'border-amber-500/40',
      bg: 'bg-amber-500/[0.05]',
      ring: 'hover:border-amber-400/70',
    }
  }
  return {
    accent: 'text-emerald-400',
    border: 'border-zinc-800',
    bg: 'bg-transparent',
    ring: 'hover:border-zinc-600',
  }
}

export function SummaryDashboard({ onPickGroup }: { onPickGroup: (name: string) => void }) {
  const { rows, quotes, status } = useStore()
  const threshold = status?.settings.rise_threshold ?? 5

  const stats = useMemo<GroupStat[]>(() => {
    // 分組順序以後端 stock_groups 的順序為準，跟 Streamlit 一致
    const order = status?.groups ? Object.keys(status.groups) : []
    const live = rows.map((r) => {
      const price = quotes[r.code] ?? r.price
      return { row: r, pct: pctOf(r, price) }
    })

    return order.map((name) => {
      const members = live.filter((x) => x.row.groups?.includes(name) && !x.row.error)
      const hits = members.filter((x) => x.pct >= threshold)
      const ups = members.filter((x) => x.pct > 0 && x.pct < threshold)
      const downs = members.filter((x) => x.pct < 0)
      const total = members.length
      const sorted = [...members].sort((a, b) => b.pct - a.pct).slice(0, 3)
      return {
        name,
        total,
        hit: hits.length,
        up: ups.length,
        down: downs.length,
        ratio: total > 0 ? (hits.length / total) * 100 : 0,
        hitNames: hits.map((x) => x.row.name),
        top3: sorted.map((x) => x.row),
        top3Pct: sorted.map((x) => x.pct),
      }
    })
  }, [rows, quotes, status, threshold])

  if (stats.length === 0) return null

  return (
    <section className="border-b border-zinc-800 px-4 py-4">
      <div className="mb-3 flex flex-wrap items-baseline gap-x-3 gap-y-1">
        <h2 className="text-[15px] font-semibold">📌 漲幅儀表板</h2>
        <span className="text-xs text-zinc-500">
          統計門檻：漲幅 ≥ {threshold}%　·　點卡片跳到該分類
        </span>
      </div>

      <div className="grid grid-cols-[repeat(auto-fill,minmax(268px,1fr))] gap-3">
        {stats.map((g) => {
          const t = tierOf(g.ratio)
          return (
            <button
              key={g.name}
              onClick={() => onPickGroup(g.name)}
              className={`flex flex-col gap-2.5 rounded-lg border p-3.5 text-left transition-colors ${t.border} ${t.bg} ${t.ring}`}
            >
              <div className="flex items-baseline justify-between gap-2">
                <span className="truncate text-sm font-semibold text-zinc-100">{g.name}</span>
                <span className="shrink-0 text-[11px] tabular-nums text-zinc-500">
                  達標 {g.ratio.toFixed(0)}%
                </span>
              </div>

              {/* 主要數字：整張卡唯一上色的數值 */}
              <div className={`font-mono text-[26px] font-semibold leading-none tabular-nums ${t.accent}`}>
                {g.hit}
                <span className="text-lg text-zinc-600"> / {g.total}</span>
              </div>

              {/* 比例條：段與段之間 2px 間隙（次要編碼，CVD 下限帶的必要條件） */}
              <div className="flex h-[6px] w-full gap-[2px] overflow-hidden rounded-sm bg-zinc-800/70">
                {[
                  { n: g.hit, c: FILL_HIT },
                  { n: g.up, c: FILL_UP },
                  { n: g.down, c: FILL_DOWN },
                ]
                  .filter((s) => s.n > 0)
                  .map((s, i) => (
                    <div
                      key={i}
                      className="h-full rounded-[1px]"
                      style={{ width: `${(s.n / Math.max(g.total, 1)) * 100}%`, background: s.c }}
                    />
                  ))}
              </div>

              {/* 三段計數：數字用文字色，識別靠色點＋文字標籤，不是只靠顏色 */}
              <div className="flex flex-col gap-1 text-xs text-zinc-400">
                <div className="flex items-start gap-1.5">
                  <span className="mt-[5px] h-2 w-2 shrink-0 rounded-[2px]" style={{ background: FILL_HIT }} />
                  <span>
                    達標 <b className="tabular-nums text-zinc-200">{g.hit}</b> 檔
                    <span className="text-zinc-500">（{compactNames(g.hitNames)}）</span>
                  </span>
                </div>
                <div className="flex items-center gap-3">
                  <span className="flex items-center gap-1.5">
                    <span className="h-2 w-2 rounded-[2px]" style={{ background: FILL_UP }} />
                    一般上漲 <b className="tabular-nums text-zinc-200">{g.up}</b>
                  </span>
                  <span className="flex items-center gap-1.5">
                    <span className="h-2 w-2 rounded-[2px]" style={{ background: FILL_DOWN }} />
                    下跌 <b className="tabular-nums text-zinc-200">{g.down}</b>
                  </span>
                </div>
              </div>

              {/* 前三名 */}
              {g.top3.length > 0 && (
                <div className="border-t border-dashed border-zinc-800 pt-2 text-[11px] leading-relaxed text-zinc-500">
                  {g.top3.map((r, i) => (
                    <span key={r.symbol}>
                      {i > 0 && <span className="text-zinc-700"> | </span>}
                      <span className="font-mono">{r.code}</span> {r.name}{' '}
                      <span
                        className={`font-mono tabular-nums ${
                          g.top3Pct[i] > 0 ? 'text-rose-400' : g.top3Pct[i] < 0 ? 'text-emerald-400' : ''
                        }`}
                      >
                        {g.top3Pct[i] > 0 ? '+' : ''}
                        {g.top3Pct[i].toFixed(1)}%
                      </span>
                    </span>
                  ))}
                </div>
              )}
            </button>
          )
        })}
      </div>
    </section>
  )
}
